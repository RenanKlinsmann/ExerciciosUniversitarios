package main;

import java.util.Locale;
import java.util.Scanner;

import entidadeCirculo.Circulo;
import entidades.Moldura;

public class Programa {

	public static void main(String[] args) {
		Locale.setDefault(Locale.US);
		Scanner sc = new Scanner (System.in);
		Moldura cal = new Moldura();
		
		
		System.out.print("Digite a Base:");
		cal.base = sc.nextDouble();
		System.out.print("Digite a Altura:");
		cal.altura = sc.nextDouble();
		System.out.print("Digite a Medida interna:");
		cal.interna = sc.nextDouble();
		
		
		
		System.out.println("Area da Moldura e = " + cal.calculaAreaTotal(cal.base, cal.altura, cal.interna) + " cm2 ");
		
		
		sc.close();
	}

}
