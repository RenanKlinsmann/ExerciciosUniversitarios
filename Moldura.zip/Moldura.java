package entidades;

public class Moldura {
	public double base;
	public double altura;
	public double interna;
	
	public double calculaAreaTotal(double base, double altura, double interna) {
		return (this.base * this.altura) - (this.interna * this.interna * this.interna * this.interna);
	}
	

}
